# 5 个不同风格范例 + 手把手点评

> 用法：每个范例都给出【题目 → 布局预算（真实数字）→ 可直接粘贴的 SCRIPT → 示意图清单 → 手把手点评】。能力弱的 agent 请连点评一起读，点评会告诉你“为什么这么排、不这么排会出什么事”。
>
> 通用前提（来自 layout-method.md）：画布 1726×980；主体可用高约 **694**；分析栏可写宽 **514**（45px 时每行约 11 字）；解答栏可写宽 **1044**，两列各约 **510**（36px 时每行约 14 字）。

---

## 范例 1：分数应用题（文字多 / 两列解答 / 示意图 / 红叉易错）

**题目**：小明有 24 颗糖，把其中的 3/8 分给小红，又把剩下的 1/3 分给小刚，最后剩多少？
**答案**：10 颗（24×3/8=9，剩 15；15×1/3=5；15−5=10）。

**布局预算**：题目行 101、总结行 113、主体 694；分析约 392（4 步骤 + 易错块）；解答约 425（两列步骤 + 答案 + 示意图 194）。两栏均 < 694，成立。

**SCRIPT**（即 `assets/template/index.html` 内置演示）：

```js
const SCRIPT = [
  { kind: "text", target: "qText", question: true,
    html: '小明有 <span id="mk-total">24</span> 颗糖果，他把其中的 \\frac{3}{8} 分给了小红，又把<span id="mk-left">剩下</span>的 \\frac{1}{3} 分给了小刚。问：小明最后还剩多少颗糖果？' },
  { kind: "mark", target: "mk-total",
    opts: { type: "underline", color: "#1976d2", strokeWidth: 2.5, padding: 6, animationDuration: 700 } },

  { kind: "text", target: "aText", html: "\u2460 先算分给小红几颗" },
  { kind: "text", target: "aText", html: "\u2461 再求<span id=\"mk-left2\">剩下</span>几颗" },
  { kind: "text", target: "aText", html: "\u2462 算分给小刚几颗" },
  { kind: "text", target: "aText", html: "\u2463 求最终剩几颗" },
  { kind: "mark", target: "mk-left2",
    opts: { type: "circle", color: "#c62828", strokeWidth: 2.5, padding: 3, animationDuration: 700 } },
  { kind: "text", target: "aText", blockClass: "wrong-block",
    html: "易错：<span id=\"mk-wrong\">24 x \\frac{1}{3} = 8</span>" },
  { kind: "mark", target: "mk-wrong",
    opts: { type: "crossed-off", color "#c62828", strokeWidth: 3, padding: 4, animationDuration: 800 } },
  { kind: "text", target: "aText", html: "错！第二次基数是 <span id=\"mk-base1\">15</span>" },

  { kind: "text", target: "sText", html: "分给小红：24 x \\frac{3}{8} = 9（颗）" },
  { kind: "text", target: "sText", html: "剩下：24 - 9 = 15（颗）" },
  { kind: "text", target: "sText", html: "分给小刚：15 x \\frac{1}{3} = 5（颗）" },
  { kind: "text", target: "sText", html: "还剩：15 - 5 = 10（颗）" },
  { kind: "text", target: "sText", blockClass: "answer",
    html: "<span id=\"mk-answer\">答：小明还剩 10 颗糖果。</span>" },
  { kind: "mark", target: "mk-answer",
    opts: { type: "box", color: "#1976d2", strokeWidth: 3, padding: 10, animationDuration: 800 } },
  { kind: "fig" },

  { kind: "text", target: "sumText",
    html: "关键：第二次分的<span id=\"mk-base\">基数变了</span>——不是 24 的 \\frac{1}{3}，是 15 的 \\frac{1}{3}。先想清楚「单位 1」是谁！" },
  { kind: "mark", target: "mk-base",
    opts: { type: "highlight", color: "#fff176", strokeWidth: 4, padding: 2, animationDuration: 700 } },
];
```
> 注意：上面 crossed-off 那行故意写成 `color "#c62828"` 演示**错误写法（漏了冒号）**，你实际使用必须写成 `color: "#c62828"`。这类漏冒号/漏引号会让整段脚本失效，写完务必 `node --check`。

**示意图清单（actFig）**：三组空心圆（9 / 5 / 10）+ 两个箭头 + 验算批注，总宽约 1080 ≤ 1044 附近，坐标算法见 layout-method 第 7.6。

**手把手点评**：
1. **分析写“怎么想”，解答写“怎么算”，别混。** 分析里是 ①②③④ 思路 + 易错警告；解答里才是带等号的算式。
2. **易错点必须放分析区，用红叉否决 + 一句批注给正确基数。** 这是这类题的灵魂：学生最容易拿 24 直接乘 1/3。
3. **解答 4 步天然成对，开两列**：左列“分给小红/小刚”，右列“剩下/还剩”，两列各 2 行水平对齐，紧凑。
4. **答案单独 `.answer` 通栏 + box**，不要塞进两列里，否则不够醒目。
5. **示意图紧跟答案（static）**，直观验证 9+5+10=24；绝不能钉在区底留空洞。
6. 记号锚点 span 必须先在 html 里写好，id 唯一；记号动作排在对应文字之后。

---

## 范例 2：几何面积（大图为主 / 公式少 / 辅助线与尺寸标注）

**题目**：一块 L 形菜地（外框长 8 m、宽 6 m，右上角缺一块长 3 m、宽 2 m 的小长方形），求面积。
**答案**：42 m²。竖切分成两个长方形：左 5×6=30，右下 3×4=12，30+12=42。

**布局预算**：题目 101、总结 113、主体 694。分析约 250（3 条思路）；解答 = 步骤 2 行 108 + 图形 figSvg 加高到 **230**（含尺寸标注）+12 ≈ 406 < 694。

**SCRIPT**：

```js
const SCRIPT = [
  { kind: "text", target: "qText", question: true,
    html: '一块 L 形菜地（外框长 <span id="mk-l\">8 m</span>、宽 6 m，右上角缺长 3 m、宽 2 m 的小块），求面积。' },
  { kind: "text", target: "aText", html: "\u2460 没学过 L 形公式" },
  { kind: "text", target: "aText", html: "\u2461 <span id=\"mk-cut\">竖切</span>成两个长方形" },
  { kind: "mark", target: "mk-cut",
    opts: { type: "circle", color: "#c62828", strokeWidth: 2.5, padding: 3, animationDuration: 700 } },
  { kind: "text", target: "aText", html: "\u2462 分别求面积再相加" },

  { kind: "text", target: "sText", html: "左边：(8 - 3) x 6 = 30（m²）" },
  { kind: "text", target: "sText", html: "右下：3 x (6 - 2) = 12（m²）" },
  { kind: "text", target: "sText", blockClass: "answer",
    html: "<span id=\"mk-answer\">面积 = 30 + 12 = 42（m²）</span>" },
  { kind: "mark", target: "mk-answer",
    opts: { type: "box", color: "#1976d2", strokeWidth: 3, padding: 10, animationDuration: 800 } },
  { kind: "fig" },

  { kind: "text", target: "sumText",
    html: "组合图形：<span id=\"mk-base\">分割成熟悉的图形</span>，各块尺寸要看准再相加。" },
  { kind: "mark", target: "mk-base",
    opts: { type: "highlight", color: "#fff176", strokeWidth: 4, padding: 2, animationDuration: 700 } },
];
```

**示意图清单（actFig）**：用 Rough.js 画 L 形外轮廓（`linearPath` 按 L 的 6 个顶点一笔）、一条竖切实线、尺寸标注（双箭头 + 8、6、3、2、4），各块内写 30 / 12。图形区高约 230。
> 不要画“补全大长方形再减小块”，那通常要画虚线表示挖去，违反“无虚线”；竖切分割全是实线，最干净。

**手把手点评**：
1. **几何题图是主角，把 figSvg 加高（约 230）**，公式只占上方两行；别让图缩成一小条。
2. **辅助线（竖切）用实线**，并在分析里圈出“竖切”这个动作，让学生知道这是你主动做的。
3. **尺寸必须标全**：尤其右下块的高是 6−2=4、左边宽是 8−3=5，这两个“算出来的尺寸”最容易错，图上要标。
4. 面积单位 `m²` 用上标小号 2 紧跟 m，不要 LaTeX。
5. 图形坐标先预算：L 外框宽高 + 四周尺寸文字要 ≤ 解答宽，尺寸文字放图形外侧别压到边。
6. 这类题文字少，**不要为了凑版面加空行**；图大、字清，版面自然饱满。

---

## 范例 3：行程问题（线段图 / 两列 / 箭头多）

**题目**：甲乙两地相距 360 km，客车每小时 70 km、货车每小时 50 km，同时相向开出，几小时相遇？
**答案**：3 小时（速度和 120，360÷120=3）；客车行 210、货车行 150。

**布局预算**：题目 101、总结 113、主体 694。分析约 300；解答两列约 200 + 线段图 194 ≈ 414 < 694。

**SCRIPT**：

```js
const SCRIPT = [
  { kind: "text", target: "qText", question: true,
    html: '甲乙两地相距 <span id="mk-d\">360 km</span>，客车每小时 70 km、货车每小时 50 km，同时相向开出，几小时相遇？' },
  { kind: "mark", target: "mk-d",
    opts: { type: "underline", color: "#1976d2", strokeWidth: 2.5, padding: 6, animationDuration: 700 } },
  { kind: "text", target: "aText", html: "\u2460 两车相向，距离在缩短" },
  { kind: "text", target: "aText", html: "\u2461 每小时共靠近 <span id=\"mk-sum\">70 + 50</span>" },
  { kind: "mark", target: "mk-sum",
    opts: { type: "circle", color: "#c62828", strokeWidth: 2.5, padding: 3, animationDuration: 700 } },
  { kind: "text", target: "aText", blockClass: "wrong-block",
    html: "易错：<span id=\"mk-wrong\">用速度差 70 - 50</span>" },
  { kind: "mark", target: "mk-wrong",
    opts: { type: "crossed-off", color: "#c62828", strokeWidth: 3, padding: 4, animationDuration: 800 } },
  { kind: "text", target: "aText", html: "错！相向要用<span id=\"mk-he\">速度和</span>" },

  { kind: "text", target: "sText", html: "速度和：70 + 50 = 120（km/h）" },
  { kind: "text", target: "sText", html: "相遇时间：360 ÷ 120 = 3（时）" },
  { kind: "text", target: "sText", html: "客车行：70 x 3 = 210（km）" },
  { kind: "text", target: "sText", html: "货车行：50 x 3 = 150（km）" },
  { kind: "text", target: "sText", blockClass: "answer",
    html: "<span id=\"mk-answer\">答：出发后 3 小时相遇。</span>" },
  { kind: "mark", target: "mk-answer",
    opts: { type: "box", color: "#1976d2", strokeWidth: 3, padding: 10, animationDuration: 800 } },
  { kind: "fig" },

  { kind: "text", target: "sumText",
    html: "相向而行：<span id=\"mk-base\">速度相加</span>，路程 ÷ 速度和 = 相遇时间。" },
  { kind: "mark", target: "mk-base",
    opts: { type: "highlight", color: "#fff176", strokeWidth: 4, padding: 2, animationDuration: 700 } },
];
```

**示意图清单（actFig）**：一条水平线段表全程（两端标“甲/乙”），左端客车箭头向右、右端货车箭头向左；相遇点按 210:150 比例落在线段上（210/360≈0.58 处），标注“相遇 · 3 时”。

**手把手点评**：
1. **相向用“速度和”、同向追及才用“速度差”**——这是行程题第一易错点，分析区用红叉把“速度差”否决掉。
2. **线段图是行程题的通用语言**：先画全程，再按各自路程比例点出相遇点，比例（210:150）要算对。
3. 解答 4 步开两列：左“速度和/时间”，右“客车/货车路程”，验证 210+150=360。
4. 箭头相向用 Rough.js 画（`line` + 两笔箭头头），方向别画反。
5. 除号这里用 `÷`（题目给的整数运算），和分数题的 x 一样都是手写常见符号。
6. 线段图坐标：线段两端要留出“甲/乙”标签的位置，箭头和文字不要超出解答宽。

---

## 范例 4：整数四则混合运算（纯纵向脱式 / 无图 / 单列）

**题目**：计算 360 + 240 ÷ 6 × 5 − 40。
**答案**：520。顺序：先 240÷6=40，再 40×5=200，再 360+200=560，最后 560−40=520。

**布局预算**：题目 101、总结 113、主体 694。分析约 240（运算顺序 3 条）；解答为**单列**脱式 5 行 ×54 = 270 + 标签 ≈ 326 < 694。

**关键排版判断**：脱式是**一条从上到下的等号链，必须单列、等号对齐**，绝不能用两列 grid（两列会把同一条脱式从中间劈开）。做法：把整个脱式写成**一个 text 段、内部用 `<br>` 换行**，并给它一个让 grid 单列的类。

**SCRIPT**：

```js
const SCRIPT = [
  { kind: "text", target: "qText", question: true,
    html: '计算 <span id="mk-expr">360 + 240 ÷ 6 × 5 - 40</span>。' },
  { kind: "mark", target: "mk-expr",
    opts: { type: "underline", color: "#1976d2", strokeWidth: 2.5, padding: 6, animationDuration: 700 } },
  { kind: "text", target: "aText", html: "\u2460 先乘除、后加减" },
  { kind: "text", target: "aText", html: "\u2461 同级运算<span id=\"mk-order\">从左到右</span>" },
  { kind: "mark", target: "mk-order",
    opts: { type: "circle", color: "#c62828", strokeWidth: 2.5, padding: 3, animationDuration: 700 } },
  { kind: "text", target: "aText", html: "\u2462 每一步只算一级，照抄其余" },

  { kind: "text", target: "sText", blockClass: "single",
    html: "<span id=\"mk-step1\">360 + 240 ÷ 6 × 5 - 40</span><br>"
        + "= 360 + <span id=\"mk-step2\">40 × 5</span> - 40<br>"
        + "= 360 + 200 - 40<br>"
        + "= <span id=\"mk-step3\">560 - 40</span><br>"
        + "= <span id=\"mk-answer\">520</span>" },
  { kind: "mark", target: "mk-step2",
    opts: { type: "circle", color: "#1976d2", strokeWidth: 2, padding: 2, animationDuration: 600 } },
  { kind: "mark", target: "mk-answer",
    opts: { type: "box", color: "#1976d2", strokeWidth: 3, padding: 8, animationDuration: 800 } },

  { kind: "text", target: "sumText",
    html: "脱式计算：<span id=\"mk-base\">先乘除后加减，同级从左到右</span>，等号对齐、逐步化简。" },
  { kind: "mark", target: "mk-base",
    opts: { type: "highlight", color: "#fff176", strokeWidth: 4, padding: 2, animationDuration: 700 } },
];
```

> 需要在模板 CSS 补一条单列类：`.zone-solution .handwrite.single { display:block; }`，并让该段等号缩进对齐（每行开头留同样空格）。无 `fig` 条目（纯计算不需要图）。

**手把手点评**：
1. **脱式单列、等号上下对齐**是这题最重要的排版；看到“一长串等号链”就立刻判断为单列，别套两列。
2. **每一步只动一处**：第一步只把 `240÷6` 变成 40，其余数字符号原样照抄，位置尽量不动——学生才能看清“这一步改了什么”。
3. 用小圆圈圈出“当前正在算的那一级”（40×5），引导视线跟随运算顺序。
4. **不要写示意图**：纯计算题画图是多余内容，违反“只保留题目要求”。
5. 运算顺序规则放分析区（先乘除后加减、同级从左到右），别放解答。
6. 最终结果 520 用 box 框；脱式最后一行就是答案，不必再单独写“答”。

---

## 范例 5：一元一次方程（代数 / 等号对齐 / 移项 / 检验）

**题目**：解方程 3x + 8 = 23。
**答案**：x = 5。两边减 8：3x=15；两边除以 3：x=5；检验 3×5+8=23。

**布局预算**：题目 101、总结 113、主体 694。分析约 240；解答单列 4 行 ×54 = 216 + 标签 ≈ 272 < 694。

**SCRIPT**：

```js
const SCRIPT = [
  { kind: "text", target: "qText", question: true,
    html: '解方程 <span id="mk-eq\">3x + 8 = 23</span>。' },
  { kind: "text", target: "aText", html: "\u2460 把 <span id=\"mk-whole\">3x</span> 看作一个整体" },
  { kind: "mark", target: "mk-whole",
    opts: { type: "circle", color: "#c62828", strokeWidth: 2.5, padding: 3, animationDuration: 700 } },
  { kind: "text", target: "aText", html: "\u2461 两边同时减 8" },
  { kind: "text", target: "aText", blockClass: "wrong-block",
    html: "易错：<span id=\"mk-wrong\">移项后忘变号</span>" },
  { kind: "mark", target: "mk-wrong",
    opts: { type: "crossed-off", color: "#c62828", strokeWidth: 3, padding: 4, animationDuration: 800 } },
  { kind: "text", target: "aText", html: "\u2462 再两边除以 3，最后检验" },

  { kind: "text", target: "sText", blockClass: "single",
    html: "<span id=\"mk-l1\">3x + 8 = 23</span><br>"
        + "<span id=\"mk-l2\">3x = 23 - 8 = 15</span><br>"
        + "<span id=\"mk-l3\">x = 15 ÷ 3</span><br>"
        + "<span id=\"mk-answer\">x = 5</span><br>"
        + "检验：3 x 5 + 8 = 23 ✓" },
  { kind: "mark", target: "mk-answer",
    opts: { type: "box", color: "#1976d2", strokeWidth: 3, padding: 8, animationDuration: 800 } },

  { kind: "text", target: "sumText",
    html: "解方程：<span id=\"mk-base\">两边做同样的运算</span>，先求含 x 的整体，再求 x，最后代回检验。" },
  { kind: "mark", target: "mk-base",
    opts: { type: "highlight", color: "#fff176", strokeWidth: 4, padding: 2, animationDuration: 700 } },
];
```

**手把手点评**：
1. **方程和脱式一样单列、等号对齐**；每一步是“等式两边同时做同一运算”，等号始终成立。
2. **思路是“先把 3x 当整体”**：先求 3x=15，再求 x=5，分析区圈出“3x”，避免学生一上来就想把 3 除掉。
3. **移项变号是易错点**：这里表现为“两边减 8”，分析区用红叉警告“移项忘变号”。
4. **一定要写检验**：把 x=5 代回原式得 23，等式成立才算对；检验跟在解后面同一列。
5. 乘号写小写 x（3 x 5），和数字 x（未知数）并排时注意区分：未知数 x 紧贴数字、乘号 x 两侧可留空格，避免混淆。
6. 最终 `x = 5` 用 box；这类题无图、版面短，**不要加空行或装饰去凑高度**。

---

## 五个范例横向对比（帮你形成判断）

| 范例 | 解答列数 | 示意图 | 记号重点 | 排版关键词 |
|---|---|---|---|---|
| 1 分数应用 | 两列 + 通栏答案 | 分组圆图 | 红叉易错、box 答案 | 两列对齐、图紧跟答案 |
| 2 几何面积 | 两列 + 通栏答案 | **大图**（加高） | 圈辅助线、尺寸标注 | 图为主、实线分割 |
| 3 行程问题 | 两列 + 通栏答案 | 线段图 | 红叉速度差、相遇点 | 比例点、相向箭头 |
| 4 四则脱式 | **单列** | 无 | 圈当前运算级 | 等号对齐、逐步化简 |
| 5 方程 | **单列** | 无 | 圈整体、box 解 | 两边同运算、检验 |

**给能力弱 agent 的三句总口诀**：
1. 先算容量（多高多宽放不放得下），再写 SCRIPT，最后必截图。
2. 成组步骤开两列、一条等号链用单列；图紧跟文字、绝不钉底留洞。
3. 一次只写一处；分析全红讲思路，解答黑字写算式，答案 box、易错红叉。
