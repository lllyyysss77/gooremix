# 特殊符号手写转写规则

> 原则：板书是“手写”，**一律不用 LaTeX 排版符号，也不用生僻 unicode**。所有符号要么用字体里现成的常见字符拼，要么用“上下结构”小组件拼。落板前先经 `normalizeSymbols()` 统一替换，再经 `tokenize()` 切成组件。

## 目录
1. 为什么不用 LaTeX
2. normalizeSymbols 替换全表
3. 结构化组件（分数 / 加减号 / 上标）
4. 箭头与常用手写写法
5. 渲染组件 CSS
6. 字体方案（在线手写体 / 本地 TTF）
7. 能力缺口与兜底

---

## 1. 为什么不用 LaTeX

- LaTeX 渲染出的是印刷排版风格，和“老师手写”不一致。
- 生僻 unicode（U+2212 等）在手写体里常常缺字形，会回退成别的字体、风格断裂。
- 手写场景的正确做法：**用最常见的字符（x、-、>、数字）+ 少量上下结构组件**，保证全部字形都能用同一手写风格写出。

---

## 2. normalizeSymbols 替换全表（落板前统一替换）

| 原始输入 | 转写为 | 说明 |
|---|---|---|
| `−` U+2212（数学减号） | `-` 半角连字符 | 用字体自带半角 `-` |
| `∶` U+2236（比号） | `：` 全角冒号 | 比号用全角冒号 |
| `\times` 或 `×` | `x` 小写字母 | **乘号一律小写 x** |
| `\div` 或 `÷` | `÷` | 除号（点-横-点，手写落板） |
| `\approx` 或 `≈` | `≈` | 约等于 |
| `\ne` / `\neq` 或 `≠` | `≠` | 不等于 |
| `\le` / `≤` | `≤` | 小于等于 |
| `\ge` / `≥` | `≥` | 大于等于 |
| `\cdot` / `·` | `·` | 间隔点（少用，优先 x） |
| `→` `\to` `\rightarrow` | `->` | 箭头 = `-` 加 `>` |
| `⇒` `\Rightarrow` | `=>` | 推出号 = `=` 加 `>` |
| `℃` | `C°` | 温度 = 大写 C + 右上角小 o |
| `％` | `%` | 半角百分号 |

实现要点：替换要在转义/渲染之前做；长串命令（`\rightarrow`）要在短串（`\to`）之前替换，避免被先截断。

---

## 3. 结构化组件（单字符拼不出，用组件拼）

`tokenize()` 把下列写法识别成组件，渲染成对应 HTML。

### 3.1 分数 `\frac{分子}{分母}`

- 渲染为**上下结构**：分子在上，中间一条横线（分母 `border-top: 2px solid currentColor`），分母在下。
- 最终画面**只显示上下结构分数，不显示 `\frac`、花括号等任何额外符号**。
- 分子、分母、横线使用**同一手写风格、同一颜色**。
- 书写动画顺序：先写分子 → 再画分数线 → 最后写分母（由 `write-fraction` 逻辑保证，仍属串行队列）。

```
\frac{3}{8}   →    3
                  ───
                   8
```

### 3.2 加减号 `\pm` 或 `±`

- 手写“加号下面画一个减号”，垂直叠放：`+` 在上、`-` 在下。

```
\pm    →    +
            -
```

### 3.3 上标 / 下标 / 度

- `²` `³` 或 `^x`、`^{abc}` → 小号字（约 .65em）紧跟母字、`vertical-align: super`。
- 平方就写“字母 + 小号数字”，如 `x^2` → x 右上角小 2，**不造专门的平方符号**。
- 度 `°` → 右上角小写 `o`。
- 下标同理用小号字下沉（如 `x_1`）。

---

## 4. 箭头与常用手写写法（补充约定）

- **加减号（正负）**：见 3.2，`+` 上 `-` 下叠写。
- **小箭头**：直接用该字体里的英文 `-` 和 `>` 拼：
  - 单向箭头 `->`：一个 `-` 紧跟一个 `>`。
  - 推出箭头 `=>`：一个 `=` 紧跟一个 `>`。
- 长箭头可把 `-` 多写几个：`-->`。
- 比较/因果优先用 `->`、`=>`，不要用 unicode 箭头（保证字形统一）。

示例板书：`甲 -> 乙`，`因为 A => 所以 B`。

---

## 5. 渲染组件 CSS（模板已内置）

```css
/* 分数：上下结构 */
.frac { display: inline-flex; flex-direction: column;
  align-items: center; vertical-align: middle;
  margin: 0 4px; line-height: 1.05; font-size: .82em; }
.frac .num { padding: 0 4px; text-align: center; }
.frac .den { padding: 0 4px; border-top: 2px solid currentColor; text-align: center; }

/* 加减号叠写 */
.pm-sym { display: inline-flex; flex-direction: column;
  align-items: center; vertical-align: middle;
  margin: 0 3px; line-height: .62; font-size: .88em; }
.pm-sym .plus  { display: block; line-height: .6; }
.pm-sym .minus { display: block; line-height: .6; }

/* 上标 */
.sup { font-size: .65em; vertical-align: super; line-height: 0; margin-left: 1px; }
```

组件用 `currentColor`，所以会自动跟随所在区颜色（分析区即红、解答区即黑），无需为每个符号单独设色。

---

## 6. 字体方案

### 6.1 默认：在线手写体 LikeJianJianTi

```html
<link rel="stylesheet" href="https://fontsapi.zeoseven.com/490/main/result.css">
```
`font-family: "LikeJianJianTi"`。题目另用 `Microsoft YaHei`。

注意：拉丁字母、数字在分片加载未到达时会回退楷体；若要稳定，应在初始化时对用到的字符做预热（collectBoardText 强制预热），或改用 6.2 本地方案。

### 6.2 高稳定：本地 TTF 手写体

需要离线/稳定、或在线字形不全时，改用本地手写 TTF（如「平方乔木体」`pingfang-qiaomu.ttf`）：

```css
@font-face {
  font-family: "PingFangQiaoMu";
  src: url("fonts/pingfang-qiaomu.ttf") format("truetype");
  font-display: block;
}
```

- 本地 TTF 可直接生成**全部板书字形与特殊符号的 SVG 路径**，不依赖在线按字截取，风格统一、无回退。
- 使用本地字体后，`font-family` 统一指向它；分数横线等仍用 CSS 组件。
- 交付时把 TTF 一并放到输出目录的 fonts/ 下（或按实际路径引用）。

---

## 7. 能力缺口与兜底（如实记录，不要假装能渲染）

- 若指定手写体**缺少某个字形**（如 ≈、≤、希腊字母），KaTeX/字体无法用该手写风格呈现：
  1. 优先**改写表达**，避开缺字（约等于就写“大概”，≤ 写成“不超过”）。
  2. 必须保留符号时，用 Rough.js **手绘该符号**（逐笔画 ≈、≤），归入图形队列，保证手写风格一致。
  3. 仍做不到，就在交付说明里写明“该符号为能力缺口、当前以 X 替代”，**不得静默回退成别的印刷字体**。
- 复杂嵌套（分数里套上标、连分数）优先拆成简单组件或拆行，不要堆叠深层结构。
- 任何替代都要保持“同一手写风格 + 串行书写”两条底线。
