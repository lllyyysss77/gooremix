---
name: board-lecture
description: 生成数学/理科“教师在黑板上逐笔书写”式教学讲解单页 HTML——黑板报分栏布局（题目/分析/解答/总结）、手写体、Rough.js 图形与 Rough Notation 手绘记号、严格串行书写动画（同一时间只写一处）。当用户要做数学题讲解板书、解题步骤逐笔动画、教学画板、黑板/白板手写演示、可播放的“分析→解答→总结”页面时使用。典型触发词：板书、黑板、解题动画、教学画板、手写讲解、逐笔书写、题目讲解、board、黑板报、教师手写。
---

# Board Lecture 板书教学画板

把一道题做成“老师在黑板上当场写”的网页：打开是空白黑板，点播放后，题目、分析、解答、示意图、总结**按顺序一处一处地写出来**，像真的有一位老师在写。

## 最终产物长什么样（先建立画面）

- 一张固定尺寸的浅蓝边框白色画布（默认 **1726 × 980**）。
- 内部分四块，像教室黑板报：
  - **题目**：通栏顶部，微软雅黑（印刷体），30px。
  - **分析**：主体左栏，手写体，**全部红色**。
  - **解答**：主体右栏，手写体，步骤可自动排成两列、三列等。
  - **总结**：通栏底部，手写体。
- 手写记号：下划线、圆圈、方框、叉、荧光高亮、删除线（Rough Notation）。
- 示意图：Rough.js 手绘线稿，逐笔描边出现。
- 画布下方附“数据契约模板”，供复制导入。

## 五条铁律（违反任何一条就是不合格）

1. **一次只写一处。** 同一时间画面上有且仅有一个书写动作，严格串行。老师只有一只手，不可能同时写两个地方。实现上用 `for...of` + `await`，禁止多个动画并发。
2. **板书字不能小。** 正文手写体 = 题目字号的 **1.5 倍**（题目 30px → 板书 45px）；某区内容特别多、需要并列多列时，最低只能到 **1.2 倍**（36px）。
3. **分析区一律红色**；其余区黑色（答案/强调可用蓝、红）。
4. **排版紧凑、自然行高。** 内容与内容之间不许留大片空洞，不许松散；示意图紧跟它说明的文字。
5. **画面只保留题目要求的内容。** 不加虚线框、网格、占位符、水印等任何“题目没要求”的装饰。

## 60 秒快速上手

1. 把 `assets/template/` **整个文件夹**复制到你的输出目录（已自包含 `index.html` 和素材图，勿只复制单个 html，否则背景/标签会丢）；按需把 index.html 改名。
2. 打开文件，找到 JS 里的 **`const SCRIPT = [ ... ]`**——这是唯一要改的数据源。
3. 按数据契约把里面的文字换成你的题目内容；数组顺序就是书写顺序。
4. 用浏览器打开，点“开始板书（串行）”看动画，点“显示全部（静态）”看成品。
5. **必须截图核对排版**（见文末“验证”），确认不溢出、不重叠、不松散。

不要改动画引擎、不要重写渲染函数；99% 的任务只需要改 `SCRIPT`。

## 数据契约（SCRIPT 数组）

每个元素是一个“动作”，共三种 `kind`：

| kind | 作用 | 关键字段 |
|---|---|---|
| `text` | 写一段字 | `target`、`html`、可选 `question`、`blockClass` |
| `mark` | 画一个手写记号 | `target`（锚点 span 的 id）、`opts` |
| `fig` | 画示意图（逐笔） | 无（图形内容在 `actFig()` 里） |

- **`target`**：写入的区域。`qText`=题目 / `aText`=分析 / `sText`=解答 / `sumText`=总结。`mark` 的 target 填 html 里 `<span id="xx">` 的 id。
- **`html`**：板书文字。支持 `\frac{3}{8}`（分数）、`\pm`（加减号叠写）、`x`（乘号）、`->` `=>`（箭头）；用 `<span id="mk-x">关键词</span>` 给记号留锚点。
- **`question: true`**：该段用微软雅黑（只给题目）。
- **`blockClass: "answer"`**：蓝色大字“答案”样式。
- **`opts`（mark 必填）**：
  - `type`：`underline` / `box` / `circle` / `highlight` / `strike-through` / `crossed-off` / `bracket`
  - `color`、`strokeWidth`、`padding`、`animationDuration`

最小示例：

```js
{ kind: "text", target: "qText", question: true,
  html: '题目：小明有 <span id="mk-total">24</span> 颗糖……' },
{ kind: "mark", target: "mk-total",
  opts: { type: "underline", color: "#1976d2", strokeWidth: 2.5, padding: 6, animationDuration: 700 } },
{ kind: "text", target: "aText", html: "① 先分析……" },
{ kind: "text", target: "sText", html: "解答步骤……" },
{ kind: "fig" },
{ kind: "text", target: "sumText", html: "总结要点……" },
```

完整可复制契约见模板画布下方区块，字段逐项说明见 `references/layout-method.md`。

## 标准工作流程

1. **读懂题**：列出已知、所求、分几步、有没有易错点（易错点放分析区，用红叉+批注）。
2. **分区**：把内容分配到 题目/分析/解答/总结。分析写“怎么想”，解答写“怎么算”，总结写“记住什么”。
3. **估容量、定布局**：按各区字数估算占多高、是否需要两列、放不放示意图（方法见下，公式在 `references/layout-method.md`）。
4. **写 SCRIPT**：按“先文字、后记号”的顺序排列；记号锚点要先在 html 里写好 span。
5. **播放自查**：确认一次只写一处、记号跟在对应文字之后。
6. **截图核对**：静态成品逐区检查，发现溢出/重叠/空洞就改 SCRIPT 或布局，重截直到合格。

## 布局方法论（要点，详细公式必读 layout-method.md）

- **用 CSS Grid 分区，不要用绝对定位硬塞坐标。** 模板已定义：
  - 画布 `grid-template-rows: auto 1fr auto`（题目 / 主体 / 总结）。
  - 主体 `grid-template-columns: 540px 1fr`（左分析 / 右解答）。
  - 让浏览器流式排版，元素自然不重叠；绝对定位只用于“示意图内部的图形坐标”。
- **先算容量再落字**：可用高度 ÷ 行高 = 能放几行；每行宽度 ÷ 单字宽 = 每行几字。超了就：缩小到 1.2 倍、改两列、或精简文字。
- **判断重叠**：对每个元素 `getBoundingClientRect()`，两个矩形若“横向区间相交 **且** 纵向区间相交”即为重叠；模板的验证方法会批量检测（见 layout-method.md）。
- **示意图用流式紧跟文字**（`position: static`），不要用 `bottom` 钉在区底，否则上方会留大空洞。
- 风格：黑板报实用排版 + 达芬奇手稿式“微潦草”（Rough.js `roughness ≈ 2.7`），潦草但信息清楚。

## 特殊符号手写转写（要点，全表见 symbol-rules.md）

落板前统一替换，**不用 LaTeX 生僻符号**：乘号写小写 `x`；除号写 `÷`；分数写“分子—横线—分母”上下结构；`\pm` 写成“+”在上“-”在下叠放；箭头 `->`（- 加 >）、`=>`（= 加 >）；上标用小号字紧跟（`x^2`）。规则与实现见 `references/symbol-rules.md`。

## 验证（必做，不许只靠推断）

排版好坏必须用截图核对，流程：

1. JS 改完先做语法检查（提取最后一个 `<script>` 内容，`node --check`）。
2. 用无头浏览器截图（Windows 下用 Edge，**必须 `--headless=new`**，旧 headless 会让圆圈/记号视觉偏移）：

```powershell
& "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" `
  --headless=new --disable-gpu --screenshot="preview.png" `
  --window-size=1780,1100 --force-device-scale-factor=1 `
  --virtual-time-budget=8000 "file:///<你的文件绝对路径>"
```

3. 打开截图，逐区检查：有无溢出画布、标签/记号位置对不对、有无重叠、有无大空洞、分析是否全红、字够不够大。
4. 若独立 `--screenshot` 出现记号偏移而你怀疑代码，可用 CDP（`--remote-debugging-port`）在页面稳定后 `Page.captureScreenshot` 复核——以稳定运行时的渲染为准。
5. 发现问题改完，**重新截图**，直到全部合格再交付。

## 参考文件导航（按需阅读）

- **`references/layout-method.md`**：布局计算、容量估算、重叠检测、排版设计的完整公式与手把手步骤——**第一次用必读**。
- **`references/symbol-rules.md`**：特殊符号手写转写全表与渲染组件。
- **`references/examples.md`**：5 个不同风格范例（分数应用、几何面积、行程问题、整数四则、方程/统计），每个都演示“怎么算布局、怎么判重叠、怎么排版”并附手把手点评。
- **`assets/template/`**：自包含标准模板文件夹（`index.html` + 素材图，含糖果题完整演示与画布下方契约）；整个文件夹复制即可用。
